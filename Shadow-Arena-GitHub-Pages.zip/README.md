# Shadow Arena

Protótipo de jogo solo 3D para navegador com arena, inimigos, rajadas de energia, explosão, esquiva, vida, pontuação e ondas.

## Publicar no GitHub Pages pelo celular
1. Abra seu repositório no GitHub.
2. Toque em **Add file** → **Upload files**.
3. Envie o arquivo `index.html` deste pacote.
4. Toque em **Commit changes**.
5. Abra **Settings** → **Pages**.
6. Em **Build and deployment**, escolha **Deploy from a branch**.
7. Selecione a branch `main` e a pasta `/(root)`, depois salve.
8. Aguarde e abra o endereço mostrado na seção Pages.

## Controles
- Celular: joystick à esquerda; Esquiva, Rajada e Explosão à direita.
- Computador: WASD ou setas para mover; Espaço para rajada; Shift para esquiva.

## Observações
- Esta é uma versão solo, não multiplayer.
- É necessária conexão com a internet para carregar a biblioteca 3D Three.js via CDN.
- O código foi preparado para navegadores móveis, mas deve ser testado no aparelho depois de publicado.
